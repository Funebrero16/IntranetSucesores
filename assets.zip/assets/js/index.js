$(document).ready(function() {
    alert("hola mundo");
});